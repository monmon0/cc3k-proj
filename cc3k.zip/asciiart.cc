#include "asciiart.h"

AsciiArt::~AsciiArt() {} 
